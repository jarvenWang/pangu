<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsesTable extends Migration
{
    /**
     * Run the migrations.
     * Create by hugo
     * 会员/代理表
     * @return void
     */
    public function up()
    {
        /*
         * id : 自增ID
         * parent_id : 上级层级ID
         * reseller_id : 所属经销商ID
         * agent_id : 直属代理商ID
         * level_id : 所属会员层级ID
         * grade_id : 所属会员等级ID\
         * name : 会员/代理真实姓名
         * username : 登陆用户名
         * password : 登陆密码
         * temp_password : 登陆时生成的临时密码
         * pay_password : 支付密码
         * email : 邮箱
         * mobile : 手机号码
         * balance : 帐户余额
         * frozen_balance : 帐户被冻结金额
         * frozen_login_time : 帐户冻结登陆时间,在此时间之前帐户无法登陆
         * fandian : 会员/代理反水设置
         * max_bonus : 限制最大中奖额
         * status : 帐户状态(1:正常,0:关闭)
         * remark : 备注信息
         * total_recharge : 充值次数
         * amount_recharge : 充值金额
         * total_cash : 提款次数
         * amount_cash : 提款金额
         * 红利金额
         * */
        Schema::create('users',function(Blueprint $table){
            $table->increments('id');
            $table->string('parent_id')->nullable();
            $table->integer('reseller_id');
            $table->integer('agent_id')->default(0);
            $table->integer('level_id')->default(0);
            $table->integer('grade_id')->default(0);
            $table->string("name");
            $table->string('username');
            $table->string('password');
            $table->string('temp_password')->nullable();
            $table->string('pay_password')->nullable();
            $table->string('email')->nullable();
            $table->string('qq',15)->nullable();
            $table->string('wechat')->nullable();
            $table->string('mobile',15);
            $table->double('balance',9,2)->default(0);
            $table->double('frozen_balance',9,2)->default(0);
            $table->timestamp('frozen_login_time')->nullable();
            $table->decimal('fandian',5,2)->default(0);
            $table->double('max_bonus',9,2)->default(0);
            $table->tinyInteger('status')->default(1);
            $table->text('remark')->nullable();
            $table->integer('total_recharge')->default(0);
            $table->double('amount_recharge',9,2)->default(0);
            $table->integer('total_cash')->default(0);
            $table->double('amount_cash',9,2)->default(0);
            $table->tinyInteger('online')->default(0);
            $table->tinyInteger('login_side')->default(1);
            $table->string('created_ip',15);
            $table->string('last_login_ip',15)->nullable();
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_address')->nullable();
            $table->integer('number');
            $table->string('remember_token');
            $table->timestamps();

            //建立索引
            $table->index('reseller_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('users');
    }
}
